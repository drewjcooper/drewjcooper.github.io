﻿using System;


    class RPNCalc
    {
    }

